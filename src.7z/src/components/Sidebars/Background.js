import React,{Component} from 'react';
import '../css/Background.css'

export default class Background extends Component {
    constructor(props){
        super(props);
    }

    render(){
        return(
            <div className="backdrop">

            </div>
        )
    }
}